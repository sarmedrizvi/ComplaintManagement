﻿namespace Project
{
    partial class ManageComplaints
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.originalButtoncs5 = new Project.OriginalButtoncs();
            this.originalButtoncs4 = new Project.OriginalButtoncs();
            this.originalButtoncs3 = new Project.OriginalButtoncs();
            this.originalButtoncs2 = new Project.OriginalButtoncs();
            this.originalButtoncs1 = new Project.OriginalButtoncs();
            this.controlBar1 = new Project.ControlBar();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.DarkRed;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.DarkRed;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.DarkRed;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.DarkRed;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridView1.Location = new System.Drawing.Point(0, 200);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1262, 428);
            this.dataGridView1.TabIndex = 45;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = global::Project.Properties.Resources.Back;
            this.pictureBox3.Location = new System.Drawing.Point(2, 46);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(47, 44);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 48;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(1160, 92);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 108);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 49;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox2.Location = new System.Drawing.Point(55, 92);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 108);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 50;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Rockwell Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(55, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 19);
            this.label1.TabIndex = 51;
            this.label1.Text = "Victim Picture";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Rockwell Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkRed;
            this.label2.Location = new System.Drawing.Point(1126, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(135, 19);
            this.label2.TabIndex = 52;
            this.label2.Text = "Complainer Picture";
            // 
            // originalButtoncs5
            // 
            this.originalButtoncs5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs5.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs5.Fontt = new System.Drawing.Font("Rockwell Extra Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs5.Location = new System.Drawing.Point(754, 96);
            this.originalButtoncs5.Name = "originalButtoncs5";
            this.originalButtoncs5.Size = new System.Drawing.Size(193, 58);
            this.originalButtoncs5.Sizee = new System.Drawing.Size(176, 22);
            this.originalButtoncs5.TabIndex = 46;
            this.originalButtoncs5.txt = "HouseRobbery";
            this.originalButtoncs5.ButtonClick += new Project.ButtonClick(this.originalButtoncs5_ButtonClick);
            // 
            // originalButtoncs4
            // 
            this.originalButtoncs4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs4.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs4.Fontt = new System.Drawing.Font("Rockwell Extra Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs4.Location = new System.Drawing.Point(953, 96);
            this.originalButtoncs4.Name = "originalButtoncs4";
            this.originalButtoncs4.Size = new System.Drawing.Size(201, 58);
            this.originalButtoncs4.Sizee = new System.Drawing.Size(206, 22);
            this.originalButtoncs4.TabIndex = 46;
            this.originalButtoncs4.txt = "OtherComplaints";
            this.originalButtoncs4.ButtonClick += new Project.ButtonClick(this.originalButtoncs4_ButtonClick);
            // 
            // originalButtoncs3
            // 
            this.originalButtoncs3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs3.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs3.Fontt = new System.Drawing.Font("Rockwell Extra Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs3.Location = new System.Drawing.Point(555, 96);
            this.originalButtoncs3.Name = "originalButtoncs3";
            this.originalButtoncs3.Size = new System.Drawing.Size(193, 58);
            this.originalButtoncs3.Sizee = new System.Drawing.Size(166, 22);
            this.originalButtoncs3.TabIndex = 46;
            this.originalButtoncs3.txt = "VehicalStolen";
            this.originalButtoncs3.ButtonClick += new Project.ButtonClick(this.originalButtoncs3_ButtonClick);
            // 
            // originalButtoncs2
            // 
            this.originalButtoncs2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs2.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs2.Fontt = new System.Drawing.Font("Rockwell Extra Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs2.Location = new System.Drawing.Point(356, 96);
            this.originalButtoncs2.Name = "originalButtoncs2";
            this.originalButtoncs2.Size = new System.Drawing.Size(193, 58);
            this.originalButtoncs2.Sizee = new System.Drawing.Size(146, 22);
            this.originalButtoncs2.TabIndex = 46;
            this.originalButtoncs2.txt = "Kidnapping";
            this.originalButtoncs2.ButtonClick += new Project.ButtonClick(this.originalButtoncs2_ButtonClick);
            // 
            // originalButtoncs1
            // 
            this.originalButtoncs1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs1.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs1.Fontt = new System.Drawing.Font("Rockwell Extra Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs1.Location = new System.Drawing.Point(157, 96);
            this.originalButtoncs1.Name = "originalButtoncs1";
            this.originalButtoncs1.Size = new System.Drawing.Size(193, 58);
            this.originalButtoncs1.Sizee = new System.Drawing.Size(145, 22);
            this.originalButtoncs1.TabIndex = 46;
            this.originalButtoncs1.txt = "StreetCrime";
            this.originalButtoncs1.ButtonClick += new Project.ButtonClick(this.originalButtoncs1_ButtonClick);
            // 
            // controlBar1
            // 
            this.controlBar1.BackColor = System.Drawing.Color.Transparent;
            this.controlBar1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.controlBar1.Dock = System.Windows.Forms.DockStyle.Top;
            this.controlBar1.Font = new System.Drawing.Font("Rockwell", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.controlBar1.ForeColor = System.Drawing.Color.Maroon;
            this.controlBar1.Icon = global::Project.Properties.Resources.Eye;
            this.controlBar1.Isclosebutton = true;
            this.controlBar1.Ismaximumsize = true;
            this.controlBar1.Isminimizebox = true;
            this.controlBar1.Location = new System.Drawing.Point(0, 0);
            this.controlBar1.MainForm = this;
            this.controlBar1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.controlBar1.Name = "controlBar1";
            this.controlBar1.Size = new System.Drawing.Size(1262, 36);
            this.controlBar1.TabIndex = 44;
            this.controlBar1.Title = "Crime Complaints";
            // 
            // ManageComplaints
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Project.Properties.Resources.BackgroundImage5;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1262, 629);
            this.ControlBox = false;
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.originalButtoncs5);
            this.Controls.Add(this.originalButtoncs4);
            this.Controls.Add(this.originalButtoncs3);
            this.Controls.Add(this.originalButtoncs2);
            this.Controls.Add(this.originalButtoncs1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.controlBar1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ManageComplaints";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.ManageComplaints_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ControlBar controlBar1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private OriginalButtoncs originalButtoncs1;
        private OriginalButtoncs originalButtoncs2;
        private OriginalButtoncs originalButtoncs3;
        private OriginalButtoncs originalButtoncs4;
        private OriginalButtoncs originalButtoncs5;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label2;
    }
}