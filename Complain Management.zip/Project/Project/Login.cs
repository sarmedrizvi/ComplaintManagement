﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Project
{
    public partial class Login : Form
    {
        public static string conn = @"Data Source=DESKTOP-12ISF3H\SQLEXPRESS;Initial Catalog=ComplaintSystem;Integrated Security=True";
        public static SqlConnection Sql = new SqlConnection(conn);
        SqlDataAdapter Apt = new SqlDataAdapter();
        DataTable Table = new DataTable();
        bool ismove = false;
        private Point LastLocation;
        public  string UserName;
      

        public Login()
        {
            InitializeComponent();
        }
        private void label2_MouseHover(object sender, EventArgs e)
        {
            label2.Size = new Size(120, 25);
        }

        private void label2_MouseLeave(object sender, EventArgs e)
        {
            label2.Size = new Size(104, 19);
        }

        private void textBoxx1_TextHover_1(object sender, EventArgs e)
        {
            textBoxx1.BACKCOLOR = Color.Red;
            textBoxx1.ImageBackColor = Color.Red;

        }

        private void textBoxx1_TextLeave_1(object sender, EventArgs e)
        {
            textBoxx1.BACKCOLOR = Color.Black;
            textBoxx1.ImageBackColor = Color.Transparent;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            RegistrationOfOfficer r = new RegistrationOfOfficer();
            r.Show();
            this.Hide();
        }

        private void pictureBox2_MouseHover_1(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.SetToolTip(this.pictureBox2, "Registration Of Officer");
            pictureBox2.Size = new Size(63, 60);
        }

        private void pictureBox2_MouseLeave_1(object sender, EventArgs e)
        {
            pictureBox2.Size = new Size(61, 50);
        }
       public static int c;
        private void pictureBox5_Click(object sender, EventArgs e)
        {
           
                if (Sql.State == ConnectionState.Closed)
                {
                    Sql.Open();
                }
                SqlCommand t = new SqlCommand("select * from RegisteredUsers where CnicNumber = " + "'" + textBoxx2.txt + "'", Sql);
                Table.Clear();
                Apt.SelectCommand = t;
                Apt.Fill(Table);
                //SqlDataReader DataRead = t.ExecuteReader();
                //DataRead.Read();
                //dataGridView1.DataSource = Table;
            if (Table.Rows.Count == 0)
            {
                MessageBox.Show("error");
            }
            else
            {
                Complaint c = new Complaint();
                if (textBoxx1.txt == Table.Rows[0]["Password"].ToString())
                {
                  
                    c.Show();
                    
                    UserName=Table.Rows[0]["Fullname"].ToString();
                    c.label1.Text = UserName.ToString();
                
                    byte[] img = ((byte[])Table.Rows[0][10]);
                    if (img == null)
                    {
                        c.pictureBox3.Image = null;

                    }
                    else
                    {
                        MemoryStream s = new MemoryStream(img);
                        c.pictureBox3.Image = Image.FromStream(s);
                    }

                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Incorrect Password Or Username");
                }
            }
        }
        ToolTip t = new ToolTip();

        private void pictureBox5_MouseHover(object sender, EventArgs e)
        {
            t.SetToolTip(this.pictureBox5, "LOGIN");
            pictureBox5.Size = new Size(132, 105);
        }

        private void pictureBox5_MouseLeave(object sender, EventArgs e)
        {
            pictureBox5.Size = new Size(124, 96);
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
