﻿namespace Project
{
    partial class Resolved
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.controlBar2 = new Project.ControlBar();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxx2 = new Project.TextBoxx();
            this.textBoxx1 = new Project.TextBoxx();
            this.backGround1 = new Project.BackGround();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.originalButtoncs1 = new Project.OriginalButtoncs();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // controlBar2
            // 
            this.controlBar2.BackColor = System.Drawing.Color.Transparent;
            this.controlBar2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.controlBar2.Dock = System.Windows.Forms.DockStyle.Top;
            this.controlBar2.Font = new System.Drawing.Font("Rockwell", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.controlBar2.ForeColor = System.Drawing.Color.Maroon;
            this.controlBar2.Icon = global::Project.Properties.Resources.Eye;
            this.controlBar2.Isclosebutton = false;
            this.controlBar2.Ismaximumsize = false;
            this.controlBar2.Isminimizebox = true;
            this.controlBar2.Location = new System.Drawing.Point(0, 0);
            this.controlBar2.MainForm = this;
            this.controlBar2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.controlBar2.Name = "controlBar2";
            this.controlBar2.Size = new System.Drawing.Size(539, 31);
            this.controlBar2.TabIndex = 34;
            this.controlBar2.Title = "Crime Complaints";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Black;
            this.label2.Font = new System.Drawing.Font("Rockwell Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkRed;
            this.label2.Location = new System.Drawing.Point(96, 222);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 19);
            this.label2.TabIndex = 43;
            this.label2.Text = "Complainer Id";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.Font = new System.Drawing.Font("Rockwell Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(96, 176);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 19);
            this.label1.TabIndex = 44;
            this.label1.Text = "Complainer Cnic Number";
            // 
            // textBoxx2
            // 
            this.textBoxx2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.textBoxx2.BackColor = System.Drawing.Color.Black;
            this.textBoxx2.BACKCOLOR = System.Drawing.Color.Black;
            this.textBoxx2.Fontt = new System.Drawing.Font("Rockwell Extra Bold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxx2.ForeColor = System.Drawing.Color.Maroon;
            this.textBoxx2.ImageBackColor = System.Drawing.Color.Transparent;
            this.textBoxx2.Location = new System.Drawing.Point(197, 210);
            this.textBoxx2.Name = "textBoxx2";
            this.textBoxx2.Size = new System.Drawing.Size(223, 46);
            this.textBoxx2.TabIndex = 40;
            this.textBoxx2.txt = "";
            // 
            // textBoxx1
            // 
            this.textBoxx1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.textBoxx1.BackColor = System.Drawing.Color.Black;
            this.textBoxx1.BACKCOLOR = System.Drawing.Color.Black;
            this.textBoxx1.Fontt = new System.Drawing.Font("Rockwell Extra Bold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxx1.ForeColor = System.Drawing.Color.Maroon;
            this.textBoxx1.ImageBackColor = System.Drawing.Color.Transparent;
            this.textBoxx1.Location = new System.Drawing.Point(267, 159);
            this.textBoxx1.Name = "textBoxx1";
            this.textBoxx1.Size = new System.Drawing.Size(153, 46);
            this.textBoxx1.TabIndex = 41;
            this.textBoxx1.txt = "";
            // 
            // backGround1
            // 
            this.backGround1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.backGround1.BackColor = System.Drawing.Color.Transparent;
            this.backGround1.Location = new System.Drawing.Point(90, 87);
            this.backGround1.Name = "backGround1";
            this.backGround1.Size = new System.Drawing.Size(359, 203);
            this.backGround1.TabIndex = 39;
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.comboBox1.BackColor = System.Drawing.Color.White;
            this.comboBox1.Font = new System.Drawing.Font("Rockwell Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "StreetCrime",
            "HouseRobbery",
            "Kidnapping",
            "OtherComplaints",
            "VehicalStolen"});
            this.comboBox1.Location = new System.Drawing.Point(220, 122);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(200, 27);
            this.comboBox1.TabIndex = 47;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Black;
            this.label3.Font = new System.Drawing.Font("Rockwell Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkRed;
            this.label3.Location = new System.Drawing.Point(96, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 19);
            this.label3.TabIndex = 46;
            this.label3.Text = "Complaint Type";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = global::Project.Properties.Resources.DoneEdited1;
            this.pictureBox2.Location = new System.Drawing.Point(219, 305);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 129;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // originalButtoncs1
            // 
            this.originalButtoncs1.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs1.Fontt = new System.Drawing.Font("Rockwell", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs1.Location = new System.Drawing.Point(172, 48);
            this.originalButtoncs1.Name = "originalButtoncs1";
            this.originalButtoncs1.Size = new System.Drawing.Size(210, 37);
            this.originalButtoncs1.Sizee = new System.Drawing.Size(58, 21);
            this.originalButtoncs1.TabIndex = 130;
            this.originalButtoncs1.txt = "Close";
            this.originalButtoncs1.ButtonClick += new Project.ButtonClick(this.originalButtoncs1_ButtonClick);
            // 
            // Resolved
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Project.Properties.Resources.BackgroundImage5Blur;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(539, 377);
            this.ControlBox = false;
            this.Controls.Add(this.originalButtoncs1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxx2);
            this.Controls.Add(this.textBoxx1);
            this.Controls.Add(this.backGround1);
            this.Controls.Add(this.controlBar2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Resolved";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ControlBar controlBar2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private TextBoxx textBoxx2;
        private TextBoxx textBoxx1;
        private BackGround backGround1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private OriginalButtoncs originalButtoncs1;
    }
}