﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;

namespace Project
{
    public partial class vehicalStolen : Form
    {
        Complaint v;
        static string conn = @"Data Source=DESKTOP-12ISF3H\SQLEXPRESS;Initial Catalog=ComplaintSystem;Integrated Security=True";

        SqlConnection Sql = new SqlConnection(conn);
        string ArrangePathOfPic;
        public vehicalStolen()
        {
            InitializeComponent();
        }
        public vehicalStolen(Complaint v)
        {
            this.v = v;
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            byte[] img = null;
            FileStream streem = new FileStream(ArrangePathOfPic, FileMode.Open, FileAccess.Read);
            BinaryReader brs = new BinaryReader(streem);
            img = brs.ReadBytes((int)streem.Length);

            Complainer c = new Complainer(pictureBox4.Image, textBoxx1.txt, dateTimePicker1.Value, Convert.ToDouble(textBoxx11.txt), Convert.ToDouble
                (textBoxx2.txt), textBoxx4.txt,textBoxx3.txt);
            VehicalStolenClass v = new VehicalStolenClass(textBoxx6.txt, textBoxx7.txt, textBoxx9.txt, textBoxx10.txt, textBoxx8.txt, false, "Vehical Stolen", dateTimePicker2.Value, textBoxx5.txt, "Stolen Vehical", textBoxx12.txt);
            if (Sql.State == ConnectionState.Closed)
            {
                Sql.Open();
            }
            SqlCommand t = new SqlCommand("insert into VehicalStolen values('" + c.FullName + "','" + c.DateOfBirth + "','" + c.PhoneNumber + "','" + c.CnicNumber + "','" + c.EmailAddress + "','" + c.PermenantAddress + "','" + v.LocationOfIncident + "','" +
                v.DateOfIncident + "','" + v.CarName + "','" + v.CarModelNo + "','" + v.CarColour + "','" + v.NumberPlate + "','" + v.EngineNumber + "'," + "@img" + ",'" + c.ComplanerId + "','" + DateTime.Now + "','" + v.Isresolve + "')", Sql);
            t.Parameters.Add(new SqlParameter("@img", img));
            t.ExecuteNonQuery();
            try
            {
                MailMessage mail = new MailMessage();
                SmtpClient smtpClient = new SmtpClient("smtp.gmail.com");
                smtpClient.Port = 587;
                smtpClient.EnableSsl = true;
                smtpClient.UseDefaultCredentials = false;
                smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtpClient.Credentials = new System.Net.NetworkCredential("sarmedrizvi@gmail.com", "settings123456");
                mail.From = new MailAddress("sarmedrizvi@gmail.com");
                mail.To.Add(c.EmailAddress);
                mail.Subject = "Street Crime Complaint";
                mail.Body = "complainer Id is" + c.ComplanerId + " \n Your complaint type is " + v.ComplaintType + "\n Your complaint date is" + DateTime.Now;
                smtpClient.Send(mail);
                MessageBox.Show(" Your Complaint has been Registered and details are send through mail");


            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);

            }

        }


        private void originalButtoncs1_ButtonClick(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Jpeg Files(*.jpg)|*.jpg |Png File(*.png)|*.png|All Files(*.*)|*.*";
            ofd.Title = "Complainer photo";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                ArrangePathOfPic = ofd.FileName;
                pictureBox4.ImageLocation = ofd.FileName;
            }
        }
        int isClicked;
        WebCam webcam;
        private void originalButtoncs2_ButtonClick(object sender, EventArgs e)
        {
            if (isClicked == 0)
            {
                webcam.Start();
                originalButtoncs2.txt = "Capture";
                isClicked = 1;

            }
            else if (isClicked == 1)
            {
                webcam.Stop();
                pictureBox4.Image = pictureBox4.Image;
                originalButtoncs2.txt = "Save";
                isClicked = 2;
            }
            else
            {
                Helper.SaveImageCapture(pictureBox4.Image);
                ArrangePathOfPic = Helper.filename;
                isClicked = 0;
                originalButtoncs2.txt = "Webcam";
            }

        }
        private void vehicalStolen_Load(object sender, EventArgs e)
        {

            webcam = new WebCam();
            webcam.InitializeWebCam(ref pictureBox4);
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            v.Show();
            this.Close();
        }
    }
}
