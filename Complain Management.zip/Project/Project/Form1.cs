﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Complaint : Form
    {
      
        int s;
        bool Hided;
        public Complaint()
        {
            InitializeComponent();
            s = 170;
            Hided = false;
            timer1.Stop();
            timer2.Start();
            timer3.Start();
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (Hided == true)
            {
                panel5.Width = panel5.Width + 10;
                if (panel5.Width >= s)
                {
                    timer1.Stop();
                    Hided = false;

                }
            }
            else
            {
                panel5.Width = panel5.Width - 10;
                if (panel5.Width <= 0)
                {
                    timer1.Stop();
                    Hided = true;
                }
            }   
        }
        private void pictureBox1_MouseHover(object sender, EventArgs e)
        {
            ToolTip tt = new ToolTip();
            tt.SetToolTip(this.pictureBox1, "Crime Complaints");
            
        }

    
        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            l.Show();
            this.Hide();
        }

        private void pictureBox4_MouseHover(object sender, EventArgs e)
        {
            ToolTip tt = new ToolTip();
            tt.SetToolTip(this.pictureBox4, "LOGOUT");
            pictureBox4.Size = new Size(80, 55);
        }

        private void pictureBox4_MouseLeave(object sender, EventArgs e)
        {
            pictureBox4.Size = new Size(75, 50);
            pictureBox4.BackColor = Color.Transparent;
        }
    
        private void originalButtoncs1_ButtonClick(object sender, EventArgs e)
        {
            StreetCrime s = new StreetCrime(this);
            s.Show();
            this.Hide();
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            Time.Text = DateTime.Now.ToString();
        }

        private void Complaint_Load(object sender, EventArgs e)
        {
          
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.SetToolTip(this.pictureBox2, "Menu");
            
        }

        private void pictureBox2_MouseHover(object sender, EventArgs e)
        {
            pictureBox2.Size = new Size(51,61);
            timer1.Start();
            Hided = true;
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            timer1.Start();
            Hided = false;
            pictureBox2.Size = new Size(44, 58);
        }

        private void panel5_MouseHover(object sender, EventArgs e)
        {
            
            timer1.Stop();
        }

        private void panel5_MouseLeave_1(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void originalButtoncs8_ButtonHover(object sender, EventArgs e)
        {
            timer1.Stop();
   
        }

        private void originalButtoncs8_ButtonLeave(object sender, EventArgs e)
        {
            timer1.Start();
   
        }

        private void originalButtoncs8_ButtonClick(object sender, EventArgs e)
        {
            ManageComplaints m = new ManageComplaints(this);
            m.Show();
            this.Hide();
        }

        private void originalButtoncs2_ButtonClick(object sender, EventArgs e)
        {
            KidnappingForm K = new KidnappingForm(this);
            K.Show();
            this.Hide();
        }

        private void originalButtoncs4_ButtonClick(object sender, EventArgs e)
        {
            vehicalStolen v = new vehicalStolen(this);
            v.Show();
            this.Hide();
        }

        private void originalButtoncs3_ButtonClick(object sender, EventArgs e)
        {
            HouseRobbery h = new HouseRobbery(this);
            h.Show();
            this.Hide();
        }

        private void originalButtoncs5_ButtonClick(object sender, EventArgs e)
        {
            otherComplaints o = new otherComplaints(this);
            o.Show();
            this.Hide();
        }
        private void originalButtoncs7_ButtonClick(object sender, EventArgs e)
        {
            ResolvedComplaints r = new ResolvedComplaints(this);
            r.Show();
            this.Hide();
        }

        private void originalButtoncs9_ButtonClick(object sender, EventArgs e)
        {
            Cancelled c = new Cancelled();
            c.Show();
        }
    }
}
