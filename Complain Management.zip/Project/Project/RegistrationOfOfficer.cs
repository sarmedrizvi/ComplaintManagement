﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net.Mail;
using System.Net;

namespace Project
{
    public partial class RegistrationOfOfficer : Form
    {
        WebCam webcam;
        string ArrangePathOfPic;
        static string conn = @"Data Source=DESKTOP-12ISF3H\SQLEXPRESS;Initial Catalog=ComplaintSystem;Integrated Security=True";
         SqlConnection Sql = new SqlConnection(conn);


        public RegistrationOfOfficer()
        {
            InitializeComponent();

        }

        private void button2_ClickButton(object sender, EventArgs e)
        {
            Complaint f = new Complaint();
            f.Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            l.Show();
            this.Hide();

        }

        private void pictureBox3_MouseHover(object sender, EventArgs e)
        {
            pictureBox3.Size = new Size(65, 60);
            ToolTip t = new ToolTip();
            t.SetToolTip(this.pictureBox3, "Back to LOGIN");
        }

        private void pictureBox3_MouseLeave(object sender, EventArgs e)
        {
            pictureBox3.Size = new Size(54, 50);
        }

        private void pictureBox2_MouseLeave_1(object sender, EventArgs e)
        {
            pictureBox2.Size = new Size(110, 43);
        }

        private void pictureBox2_MouseHover_1(object sender, EventArgs e)
        {
            pictureBox2.Size = new Size(120, 50);
            ToolTip t = new ToolTip();
            t.SetToolTip(this.pictureBox2, "Done");
        }
    
        SqlCommand t;
        private void pictureBox2_Click_1(object sender, EventArgs e)
        {
            byte[] img = null;
      


            if (string.IsNullOrEmpty(textBoxx1.txt) || string.IsNullOrEmpty(textBoxx2.txt) || string.IsNullOrEmpty(textBoxx3.txt) ||
                string.IsNullOrEmpty(textBoxx4.txt) || string.IsNullOrEmpty(textBoxx5.txt) || string.IsNullOrEmpty(textBoxx6.txt) ||
                string.IsNullOrEmpty(textBoxx7.txt) || string.IsNullOrEmpty(textBoxx8.txt) || string.IsNullOrEmpty(textBoxx12.txt) ||
                string.IsNullOrEmpty(textBoxx9.txt))
            {
                MessageBox.Show("Something is Missing");
            }
            else
            {
                if (pictureBox4.Image == null)
                {
                    MessageBox.Show("Picture is Compulsary");

                }
                else
                {

                    FileStream streem = new FileStream(ArrangePathOfPic, FileMode.Open, FileAccess.Read);
                    BinaryReader brs = new BinaryReader(streem);
                    img = brs.ReadBytes((int)streem.Length);


                    try
                    {
                        MailMessage mail = new MailMessage();
                        SmtpClient smtpClient = new SmtpClient("smtp.gmail.com");
                        smtpClient.Port = 587;
                        smtpClient.EnableSsl = true;
                        smtpClient.UseDefaultCredentials = false;
                        smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtpClient.Credentials = new System.Net.NetworkCredential("sarmedrizvi@gmail.com", "settings123456");
                        mail.From = new MailAddress("sarmedrizvi@gmail.com");
                        mail.To.Add(textBoxx3.txt.Trim());
                        mail.Subject = "Registration in Complain Management Authority";
                        mail.Body = "Dear" +textBoxx1.txt+",\n\nYour Username: " + textBoxx12.txt + "\n Your Password: " + textBoxx2.txt+"\n\n Regards,\nSaiyid Sarmed Hasan Rizvi";
                        smtpClient.Send(mail);
                        if (Sql.State == ConnectionState.Closed)
                        {
                            Sql.Open();
                        }
                        t = new SqlCommand("insert into RegisteredUsers values('" + textBoxx1.txt + "','" + comboBox1.Text + "','" + dateTimePicker1.Text
                           + "','" + textBoxx12.txt + "','" + textBoxx2.txt + "','" + textBoxx5.txt + "','" + textBoxx3.txt + "','" + textBoxx4.txt + "','"
                           + textBoxx7.txt + "','" + textBoxx8.txt + "',@img)", Sql);

                        t.Parameters.Add(new SqlParameter("@img", img));

                        t.ExecuteNonQuery();

                        MessageBox.Show(" You Are Registered and mail has been sent");

                        Login l = new Login();
                        l.Show();
                        this.Hide();

                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show(ex.Message);

                    }
                }
            }
            


        }
     
        private void originalButtoncs1_ButtonClick(object sender, EventArgs e)
        {
            webcam.Stop();
            originalButtoncs2.txt = "Webcam";
            isClicked = 0;
            openFileDialog1.Filter = "Jpeg File|*.jpg |Png File|*.png|All Files(*.*)|*.*";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                ArrangePathOfPic = openFileDialog1.FileName.ToString();
               pictureBox4.Image=Image.FromFile(openFileDialog1.FileName);
            }    
            
        }
        int isClicked = 0;

        private void originalButtoncs2_ButtonClick(object sender, EventArgs e)
        {
            if (isClicked == 0)
            {
                webcam.Start();
                originalButtoncs2.txt = "Capture";
                isClicked = 1;

            }
            else if (isClicked == 1)
            {
                webcam.Stop();
                pictureBox4.Image = pictureBox4.Image;
                originalButtoncs2.txt = "Save";
                isClicked = 2;
            }
            else
            {
                Helper.SaveImageCapture(pictureBox4.Image);
                ArrangePathOfPic = Helper.filename;
                isClicked = 0;
                originalButtoncs2.txt = "Webcam";
            }
        }

        private void RegistrationOfOfficer_Load(object sender, EventArgs e)
        {
            webcam = new WebCam();
            webcam.InitializeWebCam(ref pictureBox4);
        }

        private void originalButtoncs1_Load(object sender, EventArgs e)
        {

        }
    }
}
