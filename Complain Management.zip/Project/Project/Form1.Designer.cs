﻿namespace Project
{
    partial class Complaint
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.Time = new System.Windows.Forms.Label();
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.originalButtoncs9 = new Project.OriginalButtoncs();
            this.originalButtoncs7 = new Project.OriginalButtoncs();
            this.originalButtoncs8 = new Project.OriginalButtoncs();
            this.controlBar1 = new Project.ControlBar();
            this.originalButtoncs5 = new Project.OriginalButtoncs();
            this.originalButtoncs4 = new Project.OriginalButtoncs();
            this.originalButtoncs3 = new Project.OriginalButtoncs();
            this.originalButtoncs2 = new Project.OriginalButtoncs();
            this.originalButtoncs1 = new Project.OriginalButtoncs();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 15;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox4.Image = global::Project.Properties.Resources.LogoutButton;
            this.pictureBox4.Location = new System.Drawing.Point(1125, 226);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(65, 47);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 31;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            this.pictureBox4.MouseLeave += new System.EventHandler(this.pictureBox4_MouseLeave);
            this.pictureBox4.MouseHover += new System.EventHandler(this.pictureBox4_MouseHover);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.Image = global::Project.Properties.Resources.O1;
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(537, 51);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(216, 166);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // timer2
            // 
            this.timer2.Interval = 30;
            // 
            // Time
            // 
            this.Time.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Time.AutoSize = true;
            this.Time.BackColor = System.Drawing.Color.Transparent;
            this.Time.Font = new System.Drawing.Font("Rockwell Condensed", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Time.ForeColor = System.Drawing.Color.Maroon;
            this.Time.Location = new System.Drawing.Point(784, 617);
            this.Time.Name = "Time";
            this.Time.Size = new System.Drawing.Size(0, 29);
            this.Time.TabIndex = 38;
            // 
            // timer3
            // 
            this.timer3.Interval = 1000;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Transparent;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Controls.Add(this.originalButtoncs9);
            this.panel5.Controls.Add(this.originalButtoncs7);
            this.panel5.Controls.Add(this.originalButtoncs8);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel5.Location = new System.Drawing.Point(47, 32);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(52, 611);
            this.panel5.TabIndex = 47;
            this.panel5.MouseLeave += new System.EventHandler(this.panel5_MouseLeave_1);
            this.panel5.MouseHover += new System.EventHandler(this.panel5_MouseHover);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(47, 32);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(0, 611);
            this.panel1.TabIndex = 46;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.Controls.Add(this.pictureBox2);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(0, 32);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(47, 611);
            this.panel4.TabIndex = 45;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = global::Project.Properties.Resources.Menu;
            this.pictureBox2.Location = new System.Drawing.Point(0, 277);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 58);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 48;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            this.pictureBox2.MouseLeave += new System.EventHandler(this.pictureBox2_MouseLeave);
            this.pictureBox2.MouseHover += new System.EventHandler(this.pictureBox2_MouseHover);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 32);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(0, 611);
            this.panel3.TabIndex = 44;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(1071, 90);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(119, 118);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 96;
            this.pictureBox3.TabStop = false;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Rockwell Condensed", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(777, 575);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 31);
            this.label1.TabIndex = 97;
            this.label1.Text = "label1";
            // 
            // originalButtoncs9
            // 
            this.originalButtoncs9.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs9.Font = new System.Drawing.Font("Mistral", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs9.Fontt = new System.Drawing.Font("Rockwell", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs9.Location = new System.Drawing.Point(2, 126);
            this.originalButtoncs9.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.originalButtoncs9.Name = "originalButtoncs9";
            this.originalButtoncs9.Size = new System.Drawing.Size(166, 48);
            this.originalButtoncs9.Sizee = new System.Drawing.Size(147, 18);
            this.originalButtoncs9.TabIndex = 37;
            this.originalButtoncs9.txt = "Wrong Complaints";
            this.originalButtoncs9.ButtonHover += new Project.ButtonHover1(this.originalButtoncs8_ButtonHover);
            this.originalButtoncs9.ButtonLeave += new Project.ButtonLeave1(this.originalButtoncs8_ButtonLeave);
            this.originalButtoncs9.ButtonClick += new Project.ButtonClick(this.originalButtoncs9_ButtonClick);
            // 
            // originalButtoncs7
            // 
            this.originalButtoncs7.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs7.Font = new System.Drawing.Font("Mistral", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs7.Fontt = new System.Drawing.Font("Rockwell", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs7.Location = new System.Drawing.Point(2, 72);
            this.originalButtoncs7.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.originalButtoncs7.Name = "originalButtoncs7";
            this.originalButtoncs7.Size = new System.Drawing.Size(166, 48);
            this.originalButtoncs7.Sizee = new System.Drawing.Size(167, 18);
            this.originalButtoncs7.TabIndex = 37;
            this.originalButtoncs7.txt = "Resolved Complaints";
            this.originalButtoncs7.ButtonHover += new Project.ButtonHover1(this.originalButtoncs8_ButtonHover);
            this.originalButtoncs7.ButtonLeave += new Project.ButtonLeave1(this.originalButtoncs8_ButtonLeave);
            this.originalButtoncs7.ButtonClick += new Project.ButtonClick(this.originalButtoncs7_ButtonClick);
            // 
            // originalButtoncs8
            // 
            this.originalButtoncs8.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs8.Font = new System.Drawing.Font("Mistral", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs8.Fontt = new System.Drawing.Font("Rockwell", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs8.Location = new System.Drawing.Point(2, 18);
            this.originalButtoncs8.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.originalButtoncs8.Name = "originalButtoncs8";
            this.originalButtoncs8.Size = new System.Drawing.Size(166, 48);
            this.originalButtoncs8.Sizee = new System.Drawing.Size(158, 18);
            this.originalButtoncs8.TabIndex = 37;
            this.originalButtoncs8.txt = "Pending Complaints";
            this.originalButtoncs8.ButtonHover += new Project.ButtonHover1(this.originalButtoncs8_ButtonHover);
            this.originalButtoncs8.ButtonLeave += new Project.ButtonLeave1(this.originalButtoncs8_ButtonLeave);
            this.originalButtoncs8.ButtonClick += new Project.ButtonClick(this.originalButtoncs8_ButtonClick);
            // 
            // controlBar1
            // 
            this.controlBar1.BackColor = System.Drawing.Color.Transparent;
            this.controlBar1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.controlBar1.Dock = System.Windows.Forms.DockStyle.Top;
            this.controlBar1.Font = new System.Drawing.Font("Rockwell", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.controlBar1.ForeColor = System.Drawing.Color.Maroon;
            this.controlBar1.Icon = global::Project.Properties.Resources.Eye;
            this.controlBar1.Isclosebutton = true;
            this.controlBar1.Ismaximumsize = true;
            this.controlBar1.Isminimizebox = true;
            this.controlBar1.Location = new System.Drawing.Point(0, 0);
            this.controlBar1.MainForm = this;
            this.controlBar1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.controlBar1.Name = "controlBar1";
            this.controlBar1.Size = new System.Drawing.Size(1192, 32);
            this.controlBar1.TabIndex = 43;
            this.controlBar1.Title = "Crime Complaints";
            // 
            // originalButtoncs5
            // 
            this.originalButtoncs5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs5.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs5.Fontt = new System.Drawing.Font("Rockwell Extra Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs5.Location = new System.Drawing.Point(492, 445);
            this.originalButtoncs5.Name = "originalButtoncs5";
            this.originalButtoncs5.Size = new System.Drawing.Size(300, 69);
            this.originalButtoncs5.Sizee = new System.Drawing.Size(197, 22);
            this.originalButtoncs5.TabIndex = 37;
            this.originalButtoncs5.txt = "OtherComplains";
            this.originalButtoncs5.ButtonClick += new Project.ButtonClick(this.originalButtoncs5_ButtonClick);
            // 
            // originalButtoncs4
            // 
            this.originalButtoncs4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs4.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs4.Fontt = new System.Drawing.Font("Rockwell Extra Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs4.Location = new System.Drawing.Point(349, 359);
            this.originalButtoncs4.Name = "originalButtoncs4";
            this.originalButtoncs4.Size = new System.Drawing.Size(292, 69);
            this.originalButtoncs4.Sizee = new System.Drawing.Size(166, 22);
            this.originalButtoncs4.TabIndex = 37;
            this.originalButtoncs4.txt = "VehicalStolen";
            this.originalButtoncs4.ButtonClick += new Project.ButtonClick(this.originalButtoncs4_ButtonClick);
            // 
            // originalButtoncs3
            // 
            this.originalButtoncs3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs3.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs3.Fontt = new System.Drawing.Font("Rockwell Extra Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs3.Location = new System.Drawing.Point(647, 359);
            this.originalButtoncs3.Name = "originalButtoncs3";
            this.originalButtoncs3.Size = new System.Drawing.Size(292, 69);
            this.originalButtoncs3.Sizee = new System.Drawing.Size(176, 22);
            this.originalButtoncs3.TabIndex = 37;
            this.originalButtoncs3.txt = "HouseRobbery";
            this.originalButtoncs3.ButtonClick += new Project.ButtonClick(this.originalButtoncs3_ButtonClick);
            // 
            // originalButtoncs2
            // 
            this.originalButtoncs2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs2.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs2.Fontt = new System.Drawing.Font("Rockwell Extra Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs2.Location = new System.Drawing.Point(647, 273);
            this.originalButtoncs2.Name = "originalButtoncs2";
            this.originalButtoncs2.Size = new System.Drawing.Size(292, 69);
            this.originalButtoncs2.Sizee = new System.Drawing.Size(146, 22);
            this.originalButtoncs2.TabIndex = 37;
            this.originalButtoncs2.txt = "Kidnapping";
            this.originalButtoncs2.ButtonClick += new Project.ButtonClick(this.originalButtoncs2_ButtonClick);
            // 
            // originalButtoncs1
            // 
            this.originalButtoncs1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs1.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs1.Fontt = new System.Drawing.Font("Rockwell Extra Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs1.Location = new System.Drawing.Point(349, 273);
            this.originalButtoncs1.Name = "originalButtoncs1";
            this.originalButtoncs1.Size = new System.Drawing.Size(292, 69);
            this.originalButtoncs1.Sizee = new System.Drawing.Size(145, 22);
            this.originalButtoncs1.TabIndex = 37;
            this.originalButtoncs1.txt = "StreetCrime";
            this.originalButtoncs1.ButtonClick += new Project.ButtonClick(this.originalButtoncs1_ButtonClick);
            // 
            // Complaint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.BackgroundImage = global::Project.Properties.Resources.BackgroundImage5Blur;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1192, 643);
            this.ControlBox = false;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.controlBar1);
            this.Controls.Add(this.Time);
            this.Controls.Add(this.originalButtoncs5);
            this.Controls.Add(this.originalButtoncs4);
            this.Controls.Add(this.originalButtoncs3);
            this.Controls.Add(this.originalButtoncs2);
            this.Controls.Add(this.originalButtoncs1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox4);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Complaint";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Complaint_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Timer timer2;
        private OriginalButtoncs originalButtoncs1;
        private OriginalButtoncs originalButtoncs2;
        private OriginalButtoncs originalButtoncs3;
        private OriginalButtoncs originalButtoncs4;
        private OriginalButtoncs originalButtoncs5;
        private System.Windows.Forms.Label Time;
        private System.Windows.Forms.Timer timer3;
        private ControlBar controlBar1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private OriginalButtoncs originalButtoncs8;
        public System.Windows.Forms.PictureBox pictureBox3;
        public System.Windows.Forms.Label label1;
        private OriginalButtoncs originalButtoncs9;
        private OriginalButtoncs originalButtoncs7;
    }
}

