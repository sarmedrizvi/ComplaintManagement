﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public delegate void TextBoxHover(object sender, EventArgs e);
    public delegate void TextBoxLeave(object sender, EventArgs e);
    public partial class TextBoxx : UserControl
    {
        public event TextBoxHover TextHover;
        public event TextBoxLeave TextLeave;
        public Color BACKCOLOR { get { return textBox1.BackColor; } set { textBox1.BackColor = value; } }
        public Color ImageBackColor { get { return pictureBox1.BackColor; } set { pictureBox1.BackColor = value; } }
        public string txt { get { return textBox1.Text; } set { textBox1.Text = value; } }
        public Font Fontt { get { return textBox1.Font; } set { textBox1.Font = value; } }
        public TextBoxx()
        {
            InitializeComponent();
        }

      
        private void textBox1_MouseHover_1(object sender, EventArgs e)
        {
            textBox1.BackColor = Color.Red;
            pictureBox1.BackColor = Color.Red;
            if (TextHover != null)
                TextHover(sender, e);

        }

        private void textBox1_MouseLeave_1(object sender, EventArgs e)
        { textBox1.BackColor = Color.Black;
            pictureBox1.BackColor = Color.Black;
            if (TextLeave != null)
                TextLeave(sender, e);

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
