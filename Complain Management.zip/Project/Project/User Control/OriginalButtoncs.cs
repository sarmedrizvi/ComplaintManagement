﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public delegate void ButtonHover1(object sender, EventArgs e);
    public delegate void ButtonLeave1(object sender, EventArgs e);
    public delegate void ButtonClick(object sender, EventArgs e);
    public partial class OriginalButtoncs : UserControl
    {
        public event ButtonHover1 ButtonHover;
        public event ButtonLeave1 ButtonLeave;
        public event ButtonClick ButtonClick;
        public string txt { get { return label1.Text; } set { label1.Text = value; } }
        public Size Sizee { get {  return label1.Size; } set { label1.Size = value; } }
        public Font Fontt { get { return label1.Font; } set { label1.Font = value; } }
     //   public FontStyle Fontsize { get { return label1.Font; } set { label1.Font = value; } }

        public OriginalButtoncs()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (ButtonClick != null)
                ButtonClick(sender, e);
        }

        private void pictureBox1_MouseHover(object sender, EventArgs e)
        {
           
            if (ButtonHover != null)
                ButtonHover(sender, e);
        }

        private void pictureBox1_MouseLeave(object sender, EventArgs e)
        {
           
            if (ButtonLeave != null)
                ButtonLeave(sender, e);

        }

        private void label1_Click(object sender, EventArgs e)
        {
            if (ButtonClick != null)
                ButtonClick(sender, e);
        }

        private void label1_MouseHover(object sender, EventArgs e)
        {
          
      
            if (ButtonHover != null)
                ButtonHover(sender, e);
        }

        private void label1_MouseLeave(object sender, EventArgs e)
        {
           
         
            if (ButtonLeave != null)
                ButtonLeave(sender, e);
        }
    }
}
