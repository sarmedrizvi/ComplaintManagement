﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Net.Mail;

namespace Project
{
    public partial class StreetCrime : Form
    {
        static string conn = @"Data Source=DESKTOP-12ISF3H\SQLEXPRESS;Initial Catalog=ComplaintSystem;Integrated Security=True";
        SqlConnection Sql = new SqlConnection(conn);
        Complaint c;
        WebCam webcam;
        public StreetCrime(Complaint complaint)
        {

            c = complaint;
            InitializeComponent();
        }
        public StreetCrime()
        {

         
            InitializeComponent();
        }

        private void button2_ClickButton(object sender, EventArgs e)
        {
            Complaint f = new Complaint();
            f.Show();
            this.Hide();
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void StreetCrime_Load(object sender, EventArgs e)
        {
            webcam = new WebCam();
            webcam.InitializeWebCam(ref pictureBox4);

            timer1.Start();
        }

        private void pictureBox2_MouseHover(object sender, EventArgs e)
        {
            pictureBox2.Size = new Size(110, 60);
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            pictureBox2.Size = new Size(100, 50);
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            c.Show();
            this.Hide();

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            byte[] img = null;
            if (pictureBox4.Image == null)
            {
                MessageBox.Show("Picture is Compulsary");
            }
            else
            {

                    FileStream streem = new FileStream(ArrangePathOfPic, FileMode.Open, FileAccess.Read);
                    BinaryReader brs = new BinaryReader(streem);
                    img = brs.ReadBytes((int)streem.Length);

                    StreetCrimeClass s = new StreetCrimeClass(false, "Street Crime", dateTimePicker2.Value, textBoxx5.txt, "Street Crime", Convert.ToDouble(textBoxx7.txt), textBoxx6.txt, textBoxx10.txt);
                    Complainer s1 = new Complainer(pictureBox4.Image, textBoxx1.txt, dateTimePicker1.Value, Convert.ToDouble(textBoxx11.txt), Convert.ToDouble(textBoxx2.txt), textBoxx4.txt, textBoxx3.txt);

                    if (Sql.State == ConnectionState.Closed)
                    {
                        Sql.Open();
                    }

                    SqlCommand t = new SqlCommand("insert into StreetCrime values('" + s1.FullName + "','" + s1.DateOfBirth + "','" + s1.PhoneNumber
                   + "','" + s1.CnicNumber + "','" + s1.EmailAddress + "','" + s1.PermenantAddress + "','" + s.LocationOfIncident + "','" + s.DateOfIncident + "','"
                   + s.StolenMoney + "','" + s.LostThings + "'," + "@img,'" + DateTime.Now + "','" + s1.ComplanerId + "','" + s.Isresolve + "')", Sql);

                    t.Parameters.Add(new SqlParameter("@img", img));
                    t.ExecuteNonQuery();
                try { 
                    MailMessage mail = new MailMessage();
                    SmtpClient smtpClient = new SmtpClient("smtp.gmail.com");
                    smtpClient.Port = 587;
                    smtpClient.EnableSsl = true;
                    smtpClient.UseDefaultCredentials = false;
                    smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpClient.Credentials = new System.Net.NetworkCredential("sarmedrizvi@gmail.com", "settings123456");
                    mail.From = new MailAddress("sarmedrizvi@gmail.com");
                    mail.To.Add(s1.EmailAddress);
                    mail.Subject = "Street Crime Complaint";
                    mail.Body = "complainer Id is" + s1.ComplanerId + " \n Your complaint type is " + s.ComplaintType + "\n Your complaint date is" + DateTime.Now;
                    smtpClient.Send(mail);
                    MessageBox.Show(" Your Complaint has been Registered and details are send through mail");


                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);

                }
            }


        }
        string ArrangePathOfPic;
        private void originalButtoncs1_ButtonClick(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Jpeg Files(.jpg)|*.jpg |Png File(.png)|*.png|All Files|*.*";
            ofd.Title = "Complainer photo";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                ArrangePathOfPic = ofd.FileName;
                pictureBox4.ImageLocation = ofd.FileName;
            }
        }
        int isClicked = 0;
        private void originalButtoncs2_ButtonClick(object sender, EventArgs e)
        {
            if (isClicked == 0)
            {
                webcam.Start();
                originalButtoncs2.txt = "Capture";
                isClicked = 1;

            }
            else if (isClicked == 1)
            {
                webcam.Stop();
                pictureBox4.Image = pictureBox4.Image;
                originalButtoncs2.txt = "Save";
                isClicked = 2;
            }
            else
            {
                Helper.SaveImageCapture(pictureBox4.Image);
                ArrangePathOfPic = Helper.filename;
                isClicked = 0;
                originalButtoncs2.txt = "Webcam";
            }

        }
    }
    
}
