﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;
using System.IO;
namespace Project
{
    public partial class KidnappingForm : Form
    {
        Complaint f;
        static string conn = @"Data Source=DESKTOP-12ISF3H\SQLEXPRESS;Initial Catalog=ComplaintSystem;Integrated Security=True";
        SqlConnection Sql = new SqlConnection(conn);

        public KidnappingForm(Complaint f)
        {
            this.f = f;
            InitializeComponent();
        }
        public KidnappingForm()
        {
          
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            byte[] image = null;
            byte[] img = null;
            if (pictureBox1.Image == null && pictureBox4.Image == null)
            {
                MessageBox.Show("Picture is Compulsary");
            }
            else
            {
                //Complainer Photo
                FileStream streem = new FileStream(ArrangePath, FileMode.Open, FileAccess.Read);
                BinaryReader brs = new BinaryReader(streem);
                img = brs.ReadBytes((int)streem.Length);
                //Victim Photo

                FileStream streemm = new FileStream(ArrangePath1, FileMode.Open, FileAccess.Read);
                BinaryReader brss = new BinaryReader(streemm);
                image = brss.ReadBytes((int)streemm.Length);
                //Complainer Class
                Complainer c = new Complainer(pictureBox4.Image, textBoxx1.txt, dateTimePicker1.Value, Convert.ToDouble(textBoxx11.txt), Convert.ToDouble(textBoxx2.txt), textBoxx4.txt, textBoxx3.txt);
                //Kidnapping Complaint Class
                Kidnapping k = new Kidnapping(false, "Kidnapping", dateTimePicker2.Value, textBoxx5.txt, "Kidnapping", textBoxx12.txt, textBoxx6.txt, Convert.ToInt32(textBoxx7.txt)
                              , Convert.ToUInt32(textBoxx10.txt), textBoxx8.txt, Convert.ToInt32(textBoxx9.txt), pictureBox1.Image);
                //Sql Commands
                if (Sql.State == ConnectionState.Closed)
                {
                    Sql.Open();
                }
                SqlCommand t = new SqlCommand("insert into Kidnapping values('" + c.FullName + "','" + c.DateOfBirth + "','" + c.PhoneNumber + "','" + c.CnicNumber + "','" + c.EmailAddress + "','" + c.PermenantAddress + "','" + k.LocationOfIncident + "','" + k.DateOfIncident + "'," + " @img " + ",'" + k.VictimName + "','" +
                    k.VictimAge + "','" + k.VictimFatherName + "','" + k.VictimHeight + "','" + k.VictimCnicNo + "'," + "@image" + ",'" + c.ComplanerId + "','" + DateTime.Now + "','" + k.Isresolve + "')", Sql);
                t.Parameters.Add(new SqlParameter("@img", img));
                t.Parameters.Add(new SqlParameter("@image", image));
                t.ExecuteNonQuery();
                try
                {
                    MailMessage mail = new MailMessage();
                    SmtpClient smtpClient = new SmtpClient("smtp.gmail.com");
                    smtpClient.Port = 587;
                    smtpClient.EnableSsl = true;
                    smtpClient.UseDefaultCredentials = false;
                    smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpClient.Credentials = new System.Net.NetworkCredential("sarmedrizvi@gmail.com", "settings123456");
                    mail.From = new MailAddress("sarmedrizvi@gmail.com");
                    mail.To.Add(c.EmailAddress);
                    mail.Subject = "Kidnapping Complaint";
                    mail.Body = "complainer Id is" + c.ComplanerId + " \n Your complaint type is " + k.ComplaintType + "\n Your complaint date is" + DateTime.Now;
                    smtpClient.Send(mail);
                    MessageBox.Show(" Your Complaint has been Registered and details are send through mail");


                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);

                }
            }

        }

        private void KidnappingForm_Load(object sender, EventArgs e)
        {
            webcam = new WebCam();
            webcam.InitializeWebCam(ref pictureBox4);
            webcam1 = new WebCam();
            webcam1.InitializeWebCam(ref pictureBox1);
        }
        string ArrangePath;
        string ArrangePath1;


        private void originalButtoncs1_ButtonClick(object sender, EventArgs e)
        {
            webcam.Stop();
            webcam1.Stop();
            isClicked = 0;
            isClicked1 = 0;
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter= "Jpeg Files(*.jpg)|*.jpg |Png File(*.png)|*.png|All Files(*.*)|*.*";
            ofd.Title = "Complainer photo";
            if (ofd.ShowDialog()==DialogResult.OK)
            {
                pictureBox4.ImageLocation = ofd.FileName;
                ArrangePath = ofd.FileName;
            }

        }

        private void originalButtoncs2_ButtonClick(object sender, EventArgs e)
        {
            webcam.Stop();
            webcam1.Stop();
            isClicked = 0;
            isClicked1 = 0;
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Jpeg Files(*.jpg)|*.jpg |Png File(*.png)|*.png|All Files(*.*)|*.*";
            ofd.Title = "Victim photo";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.ImageLocation = ofd.FileName;
                ArrangePath1 = ofd.FileName;
            }
        }
        WebCam webcam, webcam1;
        int isClicked=0, isClicked1 = 0;

        private void pictureBox3_Click(object sender, EventArgs e)
        {
           
            f.Show();
            this.Close();
        }

        private void originalButtoncs4_ButtonClick(object sender, EventArgs e)
        {
            if (isClicked == 0)
            {
                webcam.Start();
                originalButtoncs4.txt = "Capture";
                isClicked = 1;

            }
            else if (isClicked == 1)
            {
                webcam.Stop();
                pictureBox4.Image = pictureBox4.Image;
                originalButtoncs4.txt = "Save";
                isClicked = 2;
            }
            else
            {
                Helper.SaveImageCapture(pictureBox4.Image);
                ArrangePath = Helper.filename;
                isClicked = 0;
                originalButtoncs4.txt = "Webcam";
            }
        }

        private void originalButtoncs3_ButtonClick(object sender, EventArgs e)
        {
            if (isClicked1 == 0)
            {
                webcam1.Start();
                originalButtoncs3.txt = "Capture";
                isClicked1 = 1;

            }
            else if (isClicked1 == 1)
            {
                webcam1.Stop();
                pictureBox1.Image = pictureBox1.Image;
                originalButtoncs3.txt = "Save";
                isClicked1 = 2;
            }
            else
            {
                Helper.SaveImageCapture(pictureBox1.Image);
                ArrangePath1 = Helper.filename;
                isClicked1 = 0;
                originalButtoncs3.txt = "Webcam";
            }
        }
    }
}
