﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;
using System.Net;

namespace Project
{
    public partial class Resolved : Form
    {
       static string conn = @"Data Source=DESKTOP-12ISF3H\SQLEXPRESS;Initial Catalog=ComplaintSystem;Integrated Security=True";
        SqlConnection Sql = new SqlConnection(conn);
        SqlDataAdapter Apt = new SqlDataAdapter();
        DataTable Table = new DataTable();

        public Resolved()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
           
            if (Sql.State == ConnectionState.Closed)
            {
                Sql.Open();
            }
            SqlCommand s = new SqlCommand("select * from \"" + comboBox1.Text + "\" where [Complainer CnicNo.] = '" + textBoxx1.txt + "'" +"and isResolved='False'", Sql);
            Table.Clear();
            Apt.SelectCommand = s;
            Apt.Fill(Table);
            if (Table.Rows.Count == 0)
            {
                MessageBox.Show("The Complaint of this type is not registered Or already resolved");
            }
            else
            {
                string tt = "update\"" + comboBox1.Text + "\"set isResolved = 'True' where [Complainer CnicNo.] = '" + textBoxx1.txt + "' and [Complainer Id] " +
                "= '" + textBoxx2.txt + "'";
                SqlCommand t = new SqlCommand(tt, Sql);
                t.ExecuteNonQuery(); 
                textBoxx1.txt = null; textBoxx2.txt = null; comboBox1.Text = null;
                MailMessage mail = new MailMessage();
                SmtpClient smtpClient = new SmtpClient("smtp.gmail.com");
                smtpClient.Port = 587;
                smtpClient.EnableSsl = true;
                smtpClient.UseDefaultCredentials = false;
                smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtpClient.Credentials = new System.Net.NetworkCredential("sarmedrizvi@gmail.com", "settings123456");
                mail.From = new MailAddress("sarmedrizvi@gmail.com");
                string email = Table.Rows[0]["Complainer EmailAddress"].ToString();
                string name = Table.Rows[0]["Complainer Name"].ToString();
                string complainerId = Table.Rows[0]["Complainer Id"].ToString();
                mail.To.Add(email);
                mail.Subject = "Registration in Complain Management Authority";
                mail.Body = "Dear " +name + ",\n\nYour Complaint with Complainer Id  "+ complainerId +" has been Resolved"+"\n\n Regards,\nSaiyid Sarmed Hasan Rizvi";
                smtpClient.Send(mail);
                MessageBox.Show("Complaint has been resolved and email has been sent to Complainer");
            }

        }

        private void originalButtoncs1_ButtonClick(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
