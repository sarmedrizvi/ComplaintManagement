﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class ResolvedComplaints : Form
    {
        string complaintType;
        Complaint c;
        public static string conn = @"Data Source=DESKTOP-12ISF3H\SQLEXPRESS;Initial Catalog=ComplaintSystem;Integrated Security=True";
        public static SqlConnection Sql = new SqlConnection(conn);
        SqlDataAdapter Apt = new SqlDataAdapter();
        DataTable Table = new DataTable();
        public ResolvedComplaints(Complaint c)
        {
            this.c = c;
            InitializeComponent();
        }
        public ResolvedComplaints()
        {
            InitializeComponent();
        }
        private void originalButtoncs6_ButtonClick(object sender, EventArgs e)
        {
            Resolved r = new Resolved();
            r.Show();

        }
        public void SQL(string s)
        {
            if (Sql.State == ConnectionState.Closed)
            {
                Sql.Open();
            }
            SqlCommand t = new SqlCommand(s, Sql);
            Table.Columns.Clear();
            Table.Clear();
            Apt.SelectCommand = t;
            Apt.Fill(Table);
            SqlDataReader DataRead = t.ExecuteReader();
            DataRead.Read();
            dataGridView1.DataSource = Table;
            DataRead.Close();

        }

        private void originalButtoncs1_ButtonClick(object sender, EventArgs e)
        {
            label1.Visible = false;
            pictureBox2.Visible = false;
            complaintType = "StreetCrime";
            string s = "select [Complainer Name],[Complainer PhoneNumber],[Complainer CnicNo.]," +
                "[Complainer Email Address],[Complainer Address],[Location Of Incident],[Date Of Incident],[Amount Of Lost],[Lost Things]," +
                "[Complaint Time],[Complainer ID]  from StreetCrime where isResolved='True' ";
            SQL(s);
        }

        private void originalButtoncs2_ButtonClick(object sender, EventArgs e)
        {
            label1.Visible = true;
            pictureBox2.Visible = true;
            complaintType = "Kidnapping";
            string s = "select [Complainer Name],[Complainer PhoneNumber],[Complainer EmailAddress],[Complainer Address],[Location of Incident]" +
                ",[date of Incident],[Victim name],[Victim Age],[Victim Cnic Number],[Victim Height],[Complainer Id],[Complaint Time]  from Kidnapping  where isResolved='True' ";
            SQL(s);
        }

        private void originalButtoncs3_ButtonClick(object sender, EventArgs e)
        {
            label1.Visible = false;
            pictureBox2.Visible = false;
            complaintType = "VehicalStolen";
            string s = "select [Complainer Name],[Complainer PhoneNumber],[Complainer EmailAddress],[Complainer Address],[Location of Incident]" +
                ",[date of Incident],[Vehical type],[Vehical Model Number],[Vehical Colour],[Number Plate],[Engine Number],[Complainer Id],[Complaint Time] from VehicalStolen  where isResolved='True' ";
            SQL(s);

        }

        private void originalButtoncs5_ButtonClick(object sender, EventArgs e)
        {
            label1.Visible = false;
            pictureBox2.Visible = false;
            complaintType = "HouseRobbery";
            string s = "select [Complainer Name],[Complainer PhoneNumber],[Complainer EmailAddress],[Complainer Address],[Location of Incident]" +
                ",[date of Incident],[Victim HouseAddress],[Amount of Lost],[Explain Briefly],[Complainer Id],[Complaint Time] from HouseRobbery  where isResolved='True' ";
            SQL(s);
        }

        private void originalButtoncs4_ButtonClick(object sender, EventArgs e)
        {
            label1.Visible = false;
            pictureBox2.Visible = false;
            complaintType = "OtherComplaints";
            string s = "select [Complainer Name],[Complainer PhoneNumber],[Complainer EmailAddress],[Complainer Address],[Location of Incident]" +
                ",[date of Incident],[Explain Briefly],[Complaint type],[Complainer Id],[Complaint Time] from OtherComplaints  where isResolved='True' ";
            SQL(s);
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            c.Show();
            this.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            if (complaintType == "Kidnapping")
            {
                int index = e.RowIndex;
                DataGridViewRow selectedRow = dataGridView1.Rows[index];

                SqlCommand t = new SqlCommand("select * from\"" + complaintType + "\"where isResolved='True' ", Sql);
                Table.Clear();
                Apt.SelectCommand = t;
                Apt.Fill(Table);
                byte[] img = ((byte[])Table.Rows[index]["Complainer photo"]);
                byte[] image = ((byte[])Table.Rows[index]["Victim Photo"]);
                if (img == null || image == null)
                {
                    pictureBox1.Image = null; pictureBox2.Image = null;

                }

                else
                {
                    MemoryStream s = new MemoryStream(img);
                    pictureBox1.Image = Image.FromStream(s);

                    MemoryStream s1 = new MemoryStream(image);
                    pictureBox2.Image = Image.FromStream(s1);

                }

            }
            else
            {

                int index = e.RowIndex;
                DataGridViewRow selectedRow = dataGridView1.Rows[index];

                SqlCommand t = new SqlCommand("select * from\"" + complaintType + "\"where isResolved='True' ", Sql);
                Table.Clear();
                Apt.SelectCommand = t;
                Apt.Fill(Table);
                byte[] img = ((byte[])Table.Rows[index]["Complainer photo"]);
                if (img == null)
                {
                    pictureBox1.Image = null;

                }
                else
                {
                    MemoryStream s = new MemoryStream(img);
                    pictureBox1.Image = Image.FromStream(s);
                }
            }


        }

        private void ResolvedComplaints_Load(object sender, EventArgs e)
        {
            label1.Visible = false;
            pictureBox2.Visible = false;
        }
    }
}
