﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace Project
{
    public partial class ManageComplaints : Form
    {
        string complaintType;
        Complaint m;
        public static string conn = @"Data Source=DESKTOP-12ISF3H\SQLEXPRESS;Initial Catalog=ComplaintSystem;Integrated Security=True";
        public static SqlConnection Sql = new SqlConnection(conn);
        SqlDataAdapter Apt = new SqlDataAdapter();
        DataTable Table = new DataTable();
        public ManageComplaints(Complaint m)
        {
            this.m = m;
            InitializeComponent();
        }
        public ManageComplaints()
        {
            
            InitializeComponent();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
          
            m.Show();
            this.Hide();
        }

        private void originalButtoncs1_ButtonClick(object sender, EventArgs e)
        {
            label1.Visible = false;
            pictureBox2.Visible = false;
            complaintType = "StreetCrime";
            if (Sql.State == ConnectionState.Closed)
            {
                Sql.Open();
            }
            SqlCommand t = new SqlCommand("select [Complainer Name],[Complainer PhoneNumber],[Complainer CnicNo.]," +
                "[Complainer Email Address],[Complainer Address],[Location Of Incident],[Date Of Incident],[Amount Of Lost],[Lost Things]," +
                "[Complaint Time],[Complainer ID]  from StreetCrime where isResolved='False' ",Sql);
            Table.Columns.Clear();
            Table.Clear();
            Apt.SelectCommand = t;
            Apt.Fill(Table);
            SqlDataReader DataRead = t.ExecuteReader();
            DataRead.Read();
            dataGridView1.DataSource = Table;
            DataRead.Close();

        }

        private void originalButtoncs2_ButtonClick(object sender, EventArgs e)
        {
            label1.Visible = true;
            pictureBox2.Visible = true;
            complaintType = "Kidnapping";
            if (Sql.State == ConnectionState.Closed)
            {
                Sql.Open();
            }
            SqlCommand t = new SqlCommand("select [Complainer Name],[Complainer PhoneNumber],[Complainer CnicNo.],[Complainer EmailAddress],[Complainer Address],[Location of Incident]" +
                ",[date of Incident],[Victim name],[Victim Age],[Victim Cnic Number],[Victim Height],[Complainer Id],[Complaint Time]  from Kidnapping  where isResolved='False' ", Sql);
            Table.Columns.Clear();
            Table.Clear();
            Apt.SelectCommand = t;
            Apt.Fill(Table);
            SqlDataReader DataRead = t.ExecuteReader();
            DataRead.Read();
            dataGridView1.DataSource = Table;
            DataRead.Close();

        }

        private void originalButtoncs3_ButtonClick(object sender, EventArgs e)
        {
            label1.Visible = false;
            pictureBox2.Visible = false;
            complaintType = "VehicalStolen";
            if (Sql.State == ConnectionState.Closed)
            {
                Sql.Open();
            }
            SqlCommand t = new SqlCommand("select [Complainer Name],[Complainer PhoneNumber],[Complainer CnicNo.],[Complainer EmailAddress],[Complainer Address],[Location of Incident]" +
                ",[date of Incident],[Vehical type],[Vehical Model Number],[Vehical Colour],[Number Plate],[Engine Number],[Complainer Id],[Complaint Time] from VehicalStolen  where isResolved='False' ", Sql);
            Table.Columns.Clear();
            Table.Clear();
            Apt.SelectCommand = t;
            Apt.Fill(Table);
            SqlDataReader DataRead = t.ExecuteReader();
            DataRead.Read();
            dataGridView1.DataSource = Table;
            DataRead.Close();
          
        }

        private void originalButtoncs5_ButtonClick(object sender, EventArgs e)
        {
            label1.Visible = false;
            pictureBox2.Visible = false;
            complaintType = "HouseRobbery";
            if (Sql.State == ConnectionState.Closed)
            {
                Sql.Open();
            }

            SqlCommand t = new SqlCommand("select [Complainer Name],[Complainer PhoneNumber],[Complainer CnicNo.],[Complainer EmailAddress],[Complainer Address],[Location of Incident]" +
                ",[date of Incident],[Victim HouseAddress],[Amount of Lost],[Explain Briefly],[Complainer Id],[Complaint Time] from HouseRobbery  where isResolved='False' ", Sql);
            Table.Columns.Clear();
            Table.Clear();
            Apt.SelectCommand = t;
            Apt.Fill(Table);
            SqlDataReader DataRead = t.ExecuteReader();
            DataRead.Read();
            dataGridView1.DataSource = Table;
            DataRead.Close();

        }

        private void originalButtoncs4_ButtonClick(object sender, EventArgs e)
        {
            label1.Visible = false;
            pictureBox2.Visible = false;
            complaintType = "OtherComplaints";
            if (Sql.State == ConnectionState.Closed)
            {
                Sql.Open();
            }
            SqlCommand t = new SqlCommand("select [Complainer Name],[Complainer PhoneNumber],[Complainer CnicNo.],[Complainer EmailAddress],[Complainer Address],[Location of Incident]" +
                ",[date of Incident],[Explain Briefly],[Complaint type],[Complainer Id],[Complaint Time] from OtherComplaints  where isResolved='False' ", Sql);
            Table.Columns.Clear();
            Table.Clear();
            Apt.SelectCommand = t;
            Apt.Fill(Table);
            SqlDataReader DataRead = t.ExecuteReader();
            DataRead.Read();
            dataGridView1.DataSource = Table;
            DataRead.Close();

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (complaintType == "Kidnapping")
            {
                int index = e.RowIndex;
                DataGridViewRow selectedRow = dataGridView1.Rows[index];

                SqlCommand t = new SqlCommand("select * from\"" + complaintType + "\"where isResolved='False' ", Sql);
                Table.Clear();
                Apt.SelectCommand = t;
                Apt.Fill(Table);
                byte[] img = ((byte[])Table.Rows[index]["Complainer photo"]);
                byte[] image = ((byte[])Table.Rows[index]["Victim Photo"]);
                if (img == null || image == null)
                {
                    pictureBox1.Image = null; pictureBox2.Image = null;

                }

                else
                {
                    MemoryStream s = new MemoryStream(img);
                    pictureBox1.Image = Image.FromStream(s);

                    MemoryStream s1 = new MemoryStream(image);
                    pictureBox2.Image = Image.FromStream(s1);

                }
                
            }
            else
            {
              
                int index = e.RowIndex;
                DataGridViewRow selectedRow = dataGridView1.Rows[index];

                SqlCommand t = new SqlCommand("select * from\"" + complaintType + "\"where isResolved='False' ", Sql);
                Table.Clear();
                Apt.SelectCommand = t;
                Apt.Fill(Table);
                byte[] img = ((byte[])Table.Rows[index]["Complainer photo"]);
                if (img == null)
                {
                    pictureBox1.Image = null;

                }
                else
                {
                    MemoryStream s = new MemoryStream(img);
                    pictureBox1.Image = Image.FromStream(s);
                }
            }
         

        }

        private void ManageComplaints_Load(object sender, EventArgs e)
        {
            label1.Visible = false;
            pictureBox2.Visible = false;
        }
    }
}
