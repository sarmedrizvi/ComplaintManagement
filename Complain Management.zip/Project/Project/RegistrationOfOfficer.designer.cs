﻿namespace Project
{
    partial class RegistrationOfOfficer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.controlBar2 = new Project.ControlBar();
            this.originalButtoncs2 = new Project.OriginalButtoncs();
            this.originalButtoncs1 = new Project.OriginalButtoncs();
            this.textBoxx1 = new Project.TextBoxx();
            this.textBoxx12 = new Project.TextBoxx();
            this.textBoxx3 = new Project.TextBoxx();
            this.textBoxx2 = new Project.TextBoxx();
            this.backGround1 = new Project.BackGround();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxx4 = new Project.TextBoxx();
            this.textBoxx5 = new Project.TextBoxx();
            this.textBoxx6 = new Project.TextBoxx();
            this.textBoxx7 = new Project.TextBoxx();
            this.textBoxx8 = new Project.TextBoxx();
            this.textBoxx9 = new Project.TextBoxx();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox3.Image = global::Project.Properties.Resources.Back;
            this.pictureBox3.Location = new System.Drawing.Point(0, 80);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(44, 50);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 26;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            this.pictureBox3.MouseLeave += new System.EventHandler(this.pictureBox3_MouseLeave);
            this.pictureBox3.MouseHover += new System.EventHandler(this.pictureBox3_MouseHover);
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Black;
            this.label8.Font = new System.Drawing.Font("Rockwell", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DarkRed;
            this.label8.Location = new System.Drawing.Point(182, 264);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(122, 18);
            this.label8.TabIndex = 85;
            this.label8.Text = "NewPassword*";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = global::Project.Properties.Resources.DoneEdited1;
            this.pictureBox2.Location = new System.Drawing.Point(374, 654);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(110, 43);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 83;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click_1);
            this.pictureBox2.MouseLeave += new System.EventHandler(this.pictureBox2_MouseLeave_1);
            this.pictureBox2.MouseHover += new System.EventHandler(this.pictureBox2_MouseHover_1);
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Black;
            this.label10.Font = new System.Drawing.Font("Rockwell", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.DarkRed;
            this.label10.Location = new System.Drawing.Point(181, 222);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(112, 18);
            this.label10.TabIndex = 73;
            this.label10.Text = "CnicNumber*";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Black;
            this.label2.Font = new System.Drawing.Font("Rockwell", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(114, 349);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 18);
            this.label2.TabIndex = 72;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Black;
            this.label9.Font = new System.Drawing.Font("Rockwell", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DarkRed;
            this.label9.Location = new System.Drawing.Point(182, 316);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(61, 18);
            this.label9.TabIndex = 70;
            this.label9.Text = "Email*";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.Font = new System.Drawing.Font("Rockwell", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(181, 110);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 18);
            this.label1.TabIndex = 65;
            this.label1.Text = "FullName*";
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.comboBox1.BackColor = System.Drawing.Color.White;
            this.comboBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox1.Font = new System.Drawing.Font("Rockwell Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.ForeColor = System.Drawing.Color.Black;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.comboBox1.Location = new System.Drawing.Point(252, 148);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.comboBox1.Size = new System.Drawing.Size(283, 27);
            this.comboBox1.TabIndex = 93;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Black;
            this.label11.Font = new System.Drawing.Font("Rockwell", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.DarkRed;
            this.label11.Location = new System.Drawing.Point(183, 185);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(97, 18);
            this.label11.TabIndex = 90;
            this.label11.Text = "DateOfBirth";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Black;
            this.label12.Font = new System.Drawing.Font("Rockwell", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.DarkRed;
            this.label12.Location = new System.Drawing.Point(182, 152);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(64, 18);
            this.label12.TabIndex = 91;
            this.label12.Text = "Gender";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dateTimePicker1.CalendarFont = new System.Drawing.Font("Rockwell Extra Bold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.CalendarForeColor = System.Drawing.Color.Black;
            this.dateTimePicker1.CalendarMonthBackground = System.Drawing.Color.Black;
            this.dateTimePicker1.CalendarTitleBackColor = System.Drawing.Color.Black;
            this.dateTimePicker1.CalendarTitleForeColor = System.Drawing.Color.Black;
            this.dateTimePicker1.CalendarTrailingForeColor = System.Drawing.Color.Black;
            this.dateTimePicker1.Font = new System.Drawing.Font("Rockwell Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(278, 180);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(257, 26);
            this.dateTimePicker1.TabIndex = 94;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox4.Location = new System.Drawing.Point(617, 110);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(100, 109);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 95;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Tag = "";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // controlBar2
            // 
            this.controlBar2.BackColor = System.Drawing.Color.Transparent;
            this.controlBar2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.controlBar2.Dock = System.Windows.Forms.DockStyle.Top;
            this.controlBar2.Font = new System.Drawing.Font("Rockwell", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.controlBar2.ForeColor = System.Drawing.Color.Maroon;
            this.controlBar2.Icon = global::Project.Properties.Resources.Eye;
            this.controlBar2.Isclosebutton = true;
            this.controlBar2.Ismaximumsize = true;
            this.controlBar2.Isminimizebox = true;
            this.controlBar2.Location = new System.Drawing.Point(0, 0);
            this.controlBar2.MainForm = this;
            this.controlBar2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.controlBar2.Name = "controlBar2";
            this.controlBar2.Size = new System.Drawing.Size(877, 35);
            this.controlBar2.TabIndex = 97;
            this.controlBar2.Title = "Crime Complaints";
            // 
            // originalButtoncs2
            // 
            this.originalButtoncs2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs2.BackColor = System.Drawing.Color.Black;
            this.originalButtoncs2.Fontt = new System.Drawing.Font("Rockwell Extra Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs2.Location = new System.Drawing.Point(587, 274);
            this.originalButtoncs2.Name = "originalButtoncs2";
            this.originalButtoncs2.Size = new System.Drawing.Size(153, 40);
            this.originalButtoncs2.Sizee = new System.Drawing.Size(109, 22);
            this.originalButtoncs2.TabIndex = 96;
            this.originalButtoncs2.txt = "Webcam";
            this.originalButtoncs2.ButtonClick += new Project.ButtonClick(this.originalButtoncs2_ButtonClick);
            // 
            // originalButtoncs1
            // 
            this.originalButtoncs1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs1.BackColor = System.Drawing.Color.Black;
            this.originalButtoncs1.Fontt = new System.Drawing.Font("Rockwell Extra Bold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs1.Location = new System.Drawing.Point(587, 220);
            this.originalButtoncs1.Name = "originalButtoncs1";
            this.originalButtoncs1.Size = new System.Drawing.Size(153, 40);
            this.originalButtoncs1.Sizee = new System.Drawing.Size(94, 22);
            this.originalButtoncs1.TabIndex = 96;
            this.originalButtoncs1.txt = "Picture";
            this.originalButtoncs1.ButtonClick += new Project.ButtonClick(this.originalButtoncs1_ButtonClick);
            this.originalButtoncs1.Load += new System.EventHandler(this.originalButtoncs1_Load);
            // 
            // textBoxx1
            // 
            this.textBoxx1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBoxx1.BackColor = System.Drawing.Color.Black;
            this.textBoxx1.BACKCOLOR = System.Drawing.Color.Black;
            this.textBoxx1.Fontt = new System.Drawing.Font("Rockwell Extra Bold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxx1.ImageBackColor = System.Drawing.Color.Transparent;
            this.textBoxx1.Location = new System.Drawing.Point(269, 98);
            this.textBoxx1.Name = "textBoxx1";
            this.textBoxx1.Size = new System.Drawing.Size(266, 44);
            this.textBoxx1.TabIndex = 87;
            this.textBoxx1.txt = "";
            // 
            // textBoxx12
            // 
            this.textBoxx12.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBoxx12.BackColor = System.Drawing.Color.Black;
            this.textBoxx12.BACKCOLOR = System.Drawing.Color.Black;
            this.textBoxx12.Fontt = new System.Drawing.Font("Rockwell Extra Bold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxx12.ImageBackColor = System.Drawing.Color.Transparent;
            this.textBoxx12.Location = new System.Drawing.Point(294, 207);
            this.textBoxx12.Name = "textBoxx12";
            this.textBoxx12.Size = new System.Drawing.Size(232, 44);
            this.textBoxx12.TabIndex = 87;
            this.textBoxx12.txt = "";
            // 
            // textBoxx3
            // 
            this.textBoxx3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBoxx3.BackColor = System.Drawing.Color.Black;
            this.textBoxx3.BACKCOLOR = System.Drawing.Color.Black;
            this.textBoxx3.Fontt = new System.Drawing.Font("Rockwell Extra Bold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxx3.ImageBackColor = System.Drawing.Color.Transparent;
            this.textBoxx3.Location = new System.Drawing.Point(244, 304);
            this.textBoxx3.Name = "textBoxx3";
            this.textBoxx3.Size = new System.Drawing.Size(291, 44);
            this.textBoxx3.TabIndex = 75;
            this.textBoxx3.txt = "";
            // 
            // textBoxx2
            // 
            this.textBoxx2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBoxx2.BackColor = System.Drawing.Color.Black;
            this.textBoxx2.BACKCOLOR = System.Drawing.Color.Black;
            this.textBoxx2.Fontt = new System.Drawing.Font("Rockwell Extra Bold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxx2.ImageBackColor = System.Drawing.Color.Transparent;
            this.textBoxx2.Location = new System.Drawing.Point(303, 254);
            this.textBoxx2.Name = "textBoxx2";
            this.textBoxx2.Size = new System.Drawing.Size(232, 44);
            this.textBoxx2.TabIndex = 81;
            this.textBoxx2.txt = "";
            // 
            // backGround1
            // 
            this.backGround1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.backGround1.BackColor = System.Drawing.Color.Transparent;
            this.backGround1.Location = new System.Drawing.Point(138, 67);
            this.backGround1.Name = "backGround1";
            this.backGround1.Size = new System.Drawing.Size(637, 581);
            this.backGround1.TabIndex = 27;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Black;
            this.label3.Font = new System.Drawing.Font("Rockwell", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkRed;
            this.label3.Location = new System.Drawing.Point(182, 361);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(159, 18);
            this.label3.TabIndex = 66;
            this.label3.Text = "PermanentAddress*";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Black;
            this.label4.Font = new System.Drawing.Font("Rockwell", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkRed;
            this.label4.Location = new System.Drawing.Point(182, 407);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(124, 18);
            this.label4.TabIndex = 67;
            this.label4.Text = "PhoneNumber*";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Black;
            this.label5.Font = new System.Drawing.Font("Rockwell", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkRed;
            this.label5.Location = new System.Drawing.Point(182, 454);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(133, 18);
            this.label5.TabIndex = 68;
            this.label5.Text = "LastOccupation*";
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Black;
            this.label13.Font = new System.Drawing.Font("Rockwell", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.DarkRed;
            this.label13.Location = new System.Drawing.Point(182, 499);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(110, 18);
            this.label13.TabIndex = 68;
            this.label13.Text = "FathersName";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Black;
            this.label7.Font = new System.Drawing.Font("Rockwell", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DarkRed;
            this.label7.Location = new System.Drawing.Point(182, 591);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(133, 18);
            this.label7.TabIndex = 69;
            this.label7.Text = "ReasonOfJoining";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Black;
            this.label6.Font = new System.Drawing.Font("Rockwell", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DarkRed;
            this.label6.Location = new System.Drawing.Point(182, 547);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(150, 18);
            this.label6.TabIndex = 71;
            this.label6.Text = "FatherOccupation*";
            // 
            // textBoxx4
            // 
            this.textBoxx4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBoxx4.BackColor = System.Drawing.Color.Black;
            this.textBoxx4.BACKCOLOR = System.Drawing.Color.Black;
            this.textBoxx4.Fontt = new System.Drawing.Font("Rockwell Extra Bold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxx4.ImageBackColor = System.Drawing.Color.Transparent;
            this.textBoxx4.Location = new System.Drawing.Point(338, 345);
            this.textBoxx4.Name = "textBoxx4";
            this.textBoxx4.Size = new System.Drawing.Size(197, 44);
            this.textBoxx4.TabIndex = 76;
            this.textBoxx4.txt = "";
            // 
            // textBoxx5
            // 
            this.textBoxx5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBoxx5.BackColor = System.Drawing.Color.Black;
            this.textBoxx5.BACKCOLOR = System.Drawing.Color.Black;
            this.textBoxx5.Fontt = new System.Drawing.Font("Rockwell Extra Bold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxx5.ImageBackColor = System.Drawing.Color.Transparent;
            this.textBoxx5.Location = new System.Drawing.Point(303, 395);
            this.textBoxx5.Name = "textBoxx5";
            this.textBoxx5.Size = new System.Drawing.Size(232, 44);
            this.textBoxx5.TabIndex = 77;
            this.textBoxx5.txt = "";
            // 
            // textBoxx6
            // 
            this.textBoxx6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBoxx6.BackColor = System.Drawing.Color.Black;
            this.textBoxx6.BACKCOLOR = System.Drawing.Color.Black;
            this.textBoxx6.Fontt = new System.Drawing.Font("Rockwell Extra Bold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxx6.ImageBackColor = System.Drawing.Color.Transparent;
            this.textBoxx6.Location = new System.Drawing.Point(312, 445);
            this.textBoxx6.Name = "textBoxx6";
            this.textBoxx6.Size = new System.Drawing.Size(223, 44);
            this.textBoxx6.TabIndex = 78;
            this.textBoxx6.txt = "";
            // 
            // textBoxx7
            // 
            this.textBoxx7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBoxx7.BackColor = System.Drawing.Color.Black;
            this.textBoxx7.BACKCOLOR = System.Drawing.Color.Black;
            this.textBoxx7.Fontt = new System.Drawing.Font("Rockwell Extra Bold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxx7.ImageBackColor = System.Drawing.Color.Transparent;
            this.textBoxx7.Location = new System.Drawing.Point(312, 486);
            this.textBoxx7.Name = "textBoxx7";
            this.textBoxx7.Size = new System.Drawing.Size(223, 44);
            this.textBoxx7.TabIndex = 79;
            this.textBoxx7.txt = "";
            // 
            // textBoxx8
            // 
            this.textBoxx8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBoxx8.BackColor = System.Drawing.Color.Black;
            this.textBoxx8.BACKCOLOR = System.Drawing.Color.Black;
            this.textBoxx8.Fontt = new System.Drawing.Font("Rockwell Extra Bold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxx8.ImageBackColor = System.Drawing.Color.Transparent;
            this.textBoxx8.Location = new System.Drawing.Point(330, 536);
            this.textBoxx8.Name = "textBoxx8";
            this.textBoxx8.Size = new System.Drawing.Size(205, 44);
            this.textBoxx8.TabIndex = 80;
            this.textBoxx8.txt = "";
            // 
            // textBoxx9
            // 
            this.textBoxx9.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBoxx9.BackColor = System.Drawing.Color.Black;
            this.textBoxx9.BACKCOLOR = System.Drawing.Color.Black;
            this.textBoxx9.Fontt = new System.Drawing.Font("Rockwell Extra Bold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxx9.ImageBackColor = System.Drawing.Color.Transparent;
            this.textBoxx9.Location = new System.Drawing.Point(312, 586);
            this.textBoxx9.Name = "textBoxx9";
            this.textBoxx9.Size = new System.Drawing.Size(344, 62);
            this.textBoxx9.TabIndex = 82;
            this.textBoxx9.txt = "";
            // 
            // RegistrationOfOfficer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImage = global::Project.Properties.Resources.BackgroundImage5Blur;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(877, 703);
            this.ControlBox = false;
            this.Controls.Add(this.controlBar2);
            this.Controls.Add(this.originalButtoncs2);
            this.Controls.Add(this.originalButtoncs1);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.textBoxx1);
            this.Controls.Add(this.textBoxx12);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.textBoxx9);
            this.Controls.Add(this.textBoxx8);
            this.Controls.Add(this.textBoxx7);
            this.Controls.Add(this.textBoxx6);
            this.Controls.Add(this.textBoxx5);
            this.Controls.Add(this.textBoxx4);
            this.Controls.Add(this.textBoxx3);
            this.Controls.Add(this.textBoxx2);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.backGround1);
            this.Controls.Add(this.pictureBox3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "RegistrationOfOfficer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RegistrationOfOfficer";
            this.Load += new System.EventHandler(this.RegistrationOfOfficer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox3;
        private BackGround backGround1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox2;
        private TextBoxx textBoxx3;
        private TextBoxx textBoxx2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label1;
        private TextBoxx textBoxx12;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private TextBoxx textBoxx1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private OriginalButtoncs originalButtoncs1;
        private ControlBar controlBar2;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private OriginalButtoncs originalButtoncs2;
        private TextBoxx textBoxx9;
        private TextBoxx textBoxx8;
        private TextBoxx textBoxx7;
        private TextBoxx textBoxx6;
        private TextBoxx textBoxx5;
        private TextBoxx textBoxx4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
    }
}