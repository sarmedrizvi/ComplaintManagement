﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    class VehicalStolenClass:Complaints
    {
        string carName;
        string carModelNo;
        string carColour;
        string numberPlate;
        string engineNumber;
        public VehicalStolenClass()
        {
            carColour = null;
            carModelNo = null;
            carColour = null;
            numberPlate = null;
            engineNumber = null;
        }
        public VehicalStolenClass(string carName, string carModelNo, string carColour, string numberPlate, string engineNumber,
            bool isResolved, string complaintContent, DateTime dateOfIncident, string locationOfIncident, string complaintType,
            string explainInBrief) : base(isResolved, complaintContent, dateOfIncident, locationOfIncident, complaintType, explainInBrief)
        {
            this.carColour = carColour;
            this.carModelNo = carModelNo;
            this.carName = carName;
            this.engineNumber = engineNumber;
            this.numberPlate = numberPlate;

        }
        public string CarName { get { return carName; } set { carName = value; } }
        public string CarModelNo { get { return carModelNo; } set { carModelNo = value; } }
        public string CarColour { get { return carColour; } set { carColour = value; } }
        public string NumberPlate { get { return numberPlate; } set { numberPlate = value; } }
        public string EngineNumber { get { return engineNumber; } set { engineNumber = value; } }
    }
}
