﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    class Kidnapping: Complaints
    {
         Image victimPhoto;
         string victimName;
         int victimAge;
         long victimCnicNo;
         string victimFatherName;
         int victimHeight;


        public Kidnapping()
        {
            victimName = "";
            victimAge = 0;
            victimCnicNo = 4210164868321;
            victimFatherName = null;
            victimHeight = 0;
        }
        
        public Kidnapping(bool isResolved, string complaintContent, DateTime dateOfIncident, string locationOfIncident, string complaintType,
            string explainInBrief,string VictimName, int VictimAge, long CNICNo, string FatherName, int Height,Image victimPhoto) : 
            base (isResolved, complaintContent, dateOfIncident, locationOfIncident, complaintType,explainInBrief)
        {
            this.VictimName = VictimName;
            this.VictimAge = VictimAge;
            this.victimCnicNo = CNICNo;
            this.victimFatherName = FatherName;
            this.victimHeight = Height;
            this.victimPhoto = victimPhoto;
        }
        public string VictimName { get { return victimName; } set { victimName = value; } }
        public int VictimAge { get { return victimAge; } set { victimAge = value; } }
        public long VictimCnicNo { get { return victimCnicNo; } set {victimCnicNo= value; } }
        public string VictimFatherName { get { return victimFatherName; } set { victimFatherName = value; } }
        public int VictimHeight { get { return victimHeight; } set { victimHeight = value; } }
        public Image VictimPhoto { get { return victimPhoto; } set { victimPhoto = value; } }















    }
}
