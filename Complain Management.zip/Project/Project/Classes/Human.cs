﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    class Human
    {
        string fullName;
        string gender;
        DateTime dateOfBirth;
        double phoneNumber;
        double cnicNumber;
        string permenantAddress;
        string emailAddress;
        string fatherName;
        Image profile;
        public Human()
        {
            fullName = null;
            dateOfBirth = DateTime.Now;
            phoneNumber = 0;
            cnicNumber = 0;
            permenantAddress = null;
            emailAddress = null;
            gender = null;
            fatherName = null;

        }
        public Human(Image profile,string fullName, DateTime dateOfBirth,double phoneNumber, double cnicNumber,string permenantAddress,
        string emailAddress)
        {
            
            this.profile = profile;
            this.fullName = fullName;
            this.dateOfBirth = dateOfBirth;
            this.permenantAddress = permenantAddress;
            this.phoneNumber = phoneNumber;
            this.cnicNumber = cnicNumber;
            this.emailAddress = emailAddress;

        }
        public Human(Image profile,string fullName,string gender, DateTime dateOfBirth, double phoneNumber, double cnicNumber, string permenantAddress,
        string emailAddress,string fatherName)
        {
            this.profile = profile;
            this.fullName = fullName;
            this.gender = gender;
            this.dateOfBirth = dateOfBirth;
            this.permenantAddress = permenantAddress;
            this.phoneNumber = phoneNumber;
            this.cnicNumber = cnicNumber;
            this.fatherName = fatherName;
            this.emailAddress = emailAddress;

        }
        public Image Profile { get { return profile; } set { profile = value; } }
        public string Gender { get { return gender; } set { gender = value; } }
        public string FullName  { get { return fullName; } set { fullName = value; } }
        public DateTime DateOfBirth { get { return dateOfBirth; } set { dateOfBirth = value; } }
        public double PhoneNumber { get { return phoneNumber; } set { phoneNumber = value; } }
        public double CnicNumber { get { return cnicNumber; } set { cnicNumber = value; } }
        public string PermenantAddress { get { return permenantAddress; } set { permenantAddress = value; } }
        public string EmailAddress { get { return emailAddress; } set { emailAddress = value; } }
        public string FatherName { get { return fatherName; } set { fatherName = value; } }
    }
}
