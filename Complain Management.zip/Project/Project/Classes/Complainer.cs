﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Project
{
    class Complainer:Human
    {
        string complainerId = "";
        static Random r = new Random();
        public Complainer()
        {
            complainerId = "0";

        }
        public Complainer(Image profile,string fullName, DateTime dateOfBirth, double phoneNumber, double cnicNumber, string permenantAddress, string emailAddress)
        :base(profile,fullName,dateOfBirth,phoneNumber,cnicNumber,permenantAddress,emailAddress)
        {
            for (int i = 0; i < 5; i++)
            {
                int a = r.Next(255);
              
                complainerId += a;
            }
        }
        public string ComplanerId { get { return complainerId; } set { complainerId = value; } }
    }
}
