﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    public partial class StreetCrimeClass : Complaints
    {

        double stolenMoney;
        string lostThings;
       
        public StreetCrimeClass()
        {
            stolenMoney = 0;
            lostThings = null;
           
        }
        public StreetCrimeClass(bool isResolved, string complaintContent, DateTime dateOfIncident, string locationOfIncident, string complaintType,
        double stolenMoney, string lostThings, string explainInBreif) : base(isResolved, complaintContent, dateOfIncident, locationOfIncident, complaintType,explainInBreif)

        {
            this.stolenMoney = stolenMoney;
            this.lostThings = lostThings;
          
        }
        public double StolenMoney { get { return stolenMoney; } set { stolenMoney = value; } }
        public string LostThings { get { return lostThings; } set { lostThings = value; } }
    }
}
