﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    class HouseRobberyClass:Complaints
    {
        string victimHouseNumber;
        long amountOfLost;
        public HouseRobberyClass()
        {
            victimHouseNumber = " ";
            amountOfLost = 0;
        }
        public HouseRobberyClass(bool isResolved, string complaintContent, DateTime dateOfIncident, string locationOfIncident, string complaintType, string explainInBrief
            ,string victimHouseNumber,long amountOfLost) :base(isResolved, complaintContent, dateOfIncident, locationOfIncident, complaintType, explainInBrief)
        {
            this.amountOfLost = amountOfLost;
            this.victimHouseNumber = victimHouseNumber;
        }
        public long AmountOfLost { get { return amountOfLost; } set { amountOfLost = value; } }
        public string VictimHouseNumber { get { return victimHouseNumber; } set { victimHouseNumber = value; } }
    }
}
