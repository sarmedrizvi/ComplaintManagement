﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
  class Register:Human
    {
      string newpassword;
      string lastOccupation;
      string fatherOccupation;
      string reasonOfJoining;
        public Register()
        {
            newpassword = null;
            lastOccupation = null;
            fatherOccupation = null;
            reasonOfJoining = null;
        }

        public Register(Image profile,string fullName, string gender, DateTime dateOfBirth, int phoneNumber, int cnicNumber, string permenantAddress,
        string emailAddress, string fatherName,string newpassword,string lastOccupation,string fatherOccupation,string reasonOfJoining)
            :base(profile,fullName,gender,dateOfBirth,phoneNumber,cnicNumber,permenantAddress,emailAddress,fatherName)
        {
           
            this.newpassword = newpassword;
            this.lastOccupation=lastOccupation;
            this.fatherOccupation=fatherOccupation;
            this.reasonOfJoining=reasonOfJoining;

        }
        public string Newpassword { get { return newpassword; }}
        public string LastOccupation { get { return lastOccupation; } set { lastOccupation = value; } }
        public string FatherOccupation { get { return fatherOccupation; } set { fatherOccupation = value; } }
        public string ReasonOfJoining { get { return reasonOfJoining; } set { reasonOfJoining = value; } }
    }
}
