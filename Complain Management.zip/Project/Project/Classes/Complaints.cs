﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
   public partial class Complaints
    {
        bool isResolved;
        string complaintType;
        string complaintContent;
        DateTime dateOfIncident;
        string locationOfIncident;
        string explainInBrief;
        public Complaints(bool isResolved, string complaintContent, DateTime dateOfIncident, string locationOfIncident, string complaintType, string explainInBrief)
        {
            this.explainInBrief = explainInBrief;
            this.complaintContent = complaintContent;
            this.isResolved = isResolved;
           this.dateOfIncident = dateOfIncident;
            this.locationOfIncident = locationOfIncident;
            this.complaintType = complaintType;
        }
        public Complaints()
        {
            isResolved = false;
            complaintContent = null;
            dateOfIncident = DateTime.Now;
            locationOfIncident = null;
        }
        public bool Isresolve { get { return isResolved; } set { isResolved = value; } }
        public string ComplaintContent { get { return complaintContent; } set { complaintContent = value; } }
        public DateTime DateOfIncident { get { return dateOfIncident; } set { dateOfIncident = value; } }
        public string LocationOfIncident { get { return locationOfIncident; } set { locationOfIncident = value; } }
        public string  ComplaintType { get { return complaintType; } set { complaintType = value; } }

        public string ExplainInBreif { get { return explainInBrief; } set { explainInBrief = value; } }

    }
}
